create definer = root@localhost trigger on_update_car
    after update
    on carriers
    for each row
BEGIN
IF (NEW.primary_contact_id IS NOT NULL) THEN
UPDATE `carrier_contacts` SET `is_primary` = (`id` = NEW.primary_contact_id) WHERE carrier_id = NEW.id;
END IF;
END;

