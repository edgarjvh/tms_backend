create definer = root@localhost trigger ins_upd_miles
    after update
    on orders
    for each row
BEGIN
IF (SELECT COUNT(*) FROM order_customer_ratings WHERE order_id = NEW.id AND rate_subtype_id IN (2,3)) > 0 THEN
UPDATE order_customer_ratings SET total_charges = (  rate * CAST( (NEW.miles / 1609.34) AS decimal(10,0) )   ) WHERE order_id = NEW.id AND rate_subtype_id IN (2,3);
END IF;

IF (SELECT COUNT(*) FROM order_carrier_ratings WHERE order_id = NEW.id AND rate_subtype_id IN (2,3)) > 0 THEN
UPDATE order_carrier_ratings SET total_charges = (  rate * CAST( (NEW.miles / 1609.34) AS decimal(10,0) )   ) WHERE order_id = NEW.id AND rate_subtype_id IN (2,3);
END IF;
END;

