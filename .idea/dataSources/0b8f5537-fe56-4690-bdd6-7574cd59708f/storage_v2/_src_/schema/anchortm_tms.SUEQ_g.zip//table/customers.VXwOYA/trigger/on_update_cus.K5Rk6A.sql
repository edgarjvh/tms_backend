create definer = root@localhost trigger on_update_cus
    after update
    on customers
    for each row
BEGIN
IF (NEW.primary_contact_id IS NOT NULL) THEN
UPDATE `customer_contacts` SET `is_primary` = (`id` = NEW.primary_contact_id) WHERE customer_id = NEW.id;
END IF;
END;

